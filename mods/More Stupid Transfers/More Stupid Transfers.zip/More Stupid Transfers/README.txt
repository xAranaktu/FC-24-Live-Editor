**More Stupid Transfers**

Trying to reproduce what was available in FIFA 18 cheat table.
Basically, this "mod" should increase the transfer activity which means more transfers between teams, but don't expect that the transfers done will be somewhat "real".


**Mod Version**: 1.0


**Edited files:**
```
    - dlc\dlc_FootballCompEng\dlc\FootballCompEng\data\Transfers\TransfersShortlistConfig.csv
```

**Changelog:**
```
1.0:
    - "Random Activity Chance Inside Deadline Day"          changed from 30 to 90
    - "Random Activity Chance Inside Transfer Window"       changed from 15 to 75
    - "Random Activity Chance Outside Transfer Window"      changed from 0 to 55
    - "Max Number Of Teams To Search"                       changed from 5 to 8
    - "Min Days Between Offers"                             changed from 3 to 2
    - "Max Attempts To Find Suitable Team"                  changed from 2 to 6
    - "Overall Difference Per Attempt Transfer"             changed from 4 to 3
    - "Overall Difference Per Attempt Loan"                 changed from 8 to 6
```
**How to install:**
```
1. Unzip archive
2. Move the root folder to C:\FIFA 23 Live Editor\mods (replace files if needed) <https://i.imgur.com/AVlGGKZ.png>
3. Run the game & Live Editor

```

![](https://i.imgur.com/AVlGGKZ.png)