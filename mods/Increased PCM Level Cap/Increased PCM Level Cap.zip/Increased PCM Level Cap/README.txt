**Increased Player Career Mode Level Cap**

**Mod Version**: 1.0

```
This mod increases the level cap in player career mode from 50 to 99

IT DOESN'T GIVE YOU 99 LEVEL...
```

**Edited files:**
```
    - dlc\dlc_FootballCompEng\dlc\FootballCompEng\data\PlayerGrowth\player_growth.json
```

**Changelog:**
```

```
**How to install:**
```
1. Unzip archive
2. Move the root folder to C:\FC 24 Live Editor\mods (replace files if needed) <https://i.imgur.com/AVlGGKZ.png>
3. Run the game & Live Editor
```

https://i.imgur.com/7puQBqY.png