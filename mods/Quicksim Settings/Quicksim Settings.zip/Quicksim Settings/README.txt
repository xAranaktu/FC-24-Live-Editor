**Quicksim Settings**

No cards & No injuries during quick sims

**Mod Version**: 1.0


**Edited files:**
```
    - dlc\dlc_FootballCompEng\dlc\FootballCompEng\data\simsettings.ini
```

**Changelog:**
```
1.0:
    - Max number of cards in a game                         4   ->  0
    - Chance of a yellow card in the game                   45  ->  0
    - Percentage chance of a red card being brandished      32  ->  0
    - Percentage chance of receiving two reds in a game     2   ->  0
    - Possible maximum number of injuries in a game         2   ->  0

```
**How to install:**
```
1. Unzip archive
2. Move the root folder to C:\FC 24 Live Editor\mods (replace files if needed) <https://i.imgur.com/AVlGGKZ.png>
3. Run the game & Live Editor
```

![](https://i.imgur.com/AVlGGKZ.png)